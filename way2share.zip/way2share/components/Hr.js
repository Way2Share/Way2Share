import React, { PureComponent } from 'react';
import {
  View
} from 'react-native';


export default function Hr(props) {
	    return <View style={ { borderBottomWidth: 1, borderColor: "rgba(0,0,0,0.1)"} }></View>
}

