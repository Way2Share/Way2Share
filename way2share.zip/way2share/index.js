import { AppRegistry } from 'react-native';
import App from './App';

AppRegistry.registerComponent('way2share', () => App);
